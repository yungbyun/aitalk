library(readxl)
library(dplyr)
library(neuralnet)
read_excel("emotion_categories Amended.xlsx") -> emdf

names(emdf)
emdf->Bemdf

for (i in 1:100) {
  rbind(Bemdf, emdf) -> Bemdf
}

set.seed(100)
nn = neuralnet(NExcited + NHappy + NSadness + NSurprised + NDisgust + NFear + NAnger +
                 ISA_Emotion + IS_Positively_Valence + IS_Negatively_Valence + IS_High_Arousal +
                 IS_Low_Arousal + CAN_Approach + CAN_Withdraw + HAS_Smile + HAS_Frown + HAS_Scrunched_Nose +
                 HAS_Scowl + HAS_raised_eyebrows + HAS_wrinkled_eyebrows + HAS_widen_eyes +
                 FEELS_GOOD + RAISES_BP ~ Excited + Happy + Sadness + Surprised +             
                 Disgust + Fear + Anger, 
               data=Bemdf,hidden = 6, stepmax=1e7)

#now we want to isolate the weights

nn$weights[[1]][[1]]
matrix(nn$weights[[1]][[1]], ncol = 6, nrow = 8)->hw
exInput<- matrix(c(1,1,0,0,0,0,0,0),nrow=1,ncol=8)

exInput%*%hw -> exact
round(exact, 2)

#write similar code for the other emotions
