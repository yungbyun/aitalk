# This file will use the IAC network (similar to the Jets and Sharks Network)
#to investigate the choice between Coke and V8

# First let's take in the givens: inputs and weights.

##########Read in weight file


library(readxl) #alternative: read as a csv file
library(tidyverse)

#you will need to point to the directory in which the file is located

drinkwts <- read_excel("CokeV8.xlsx")
#I'm going to treat the rows as the sending wts and the cols as the recv wts
#So what are all the connections weights received by the hidden unit KenH


#drinkwts %>% View() 

#Instead of specifying an input file we shall just activated units directly

CVinput <- c(1, 0, 0, 0, 0, 0, 0, 0, 0) #this is for Coke
#Think about the V8 input

#Now we have the weights and the inputs loaded

#Let's examine the main routine

#######Main (Same as Jets and Sharks)
#parameters
alpha <- 0.1
decay <- 0.1 #will get subtracted
estr<-0.4

max<-1
min<- -0.2
rest <- -0.1 #don't decay below rest

numcycles <- 100

#want a vector that will contain the current activation
curract<-rep(rest, length(CVinput)) #there are 9 units in the drinks network


########FUNCTIONS

spreadact <- function(act) {
#logic
#first enter the input
#each non-negative receiving unit should get the product of incoming weights 
#and the sending activation, if non-negative. Then multiply by alpha
#we also want to decay all activations

#what are the incoming weights to say to the jth unit? jswts[,j+1]
  
  
#enter input
  act <- act + estr*CVinput

#Let's make a version of act in which all the values less than zero are zero
  chact <- c()
  nnact <- act
  nnact[nnact < 0] <- 0
  
  for (i in 1:length(act)) {
    chact[i] <- alpha*(sum(nnact*t(drinkwts[,i+1]))) #this is the net input
  }
  
  #act <- act + chact 
  
  
  #If chact[i] is positive, scale it by (max-a[i])
  #If chact[i] is negative, scale it by (a[i]-min) 
  
  for (i in 1:length(act)) {
    if (chact[i] >= 0) {
      chact[i] <- chact[i]*(max-act[i])-decay*(act[i]-rest)
    } else if (chact[i] < 0) {
      chact[i] <- chact[i]*(act[i]-min)-decay*(act[i]-rest)
    }
  }
  
  act <- act + chact 
  
  return(act)
}

adjustact <- function(act) {
  #logic
  #if below max or min adjust. 
  
  for (i in 1:length(act)) {
    if (act[i] > max) {
      act[i] <- max
    } else if (act[i] < min) {
      act[i] <- min
    }
  }
  
  return(act)
}

#########
#########
####MAIN

#What happens next? For a series of cycles:
#activation must spread according to weights
#the current activation must be adjusted according to output function


for (c in 1: numcycles) {
  spreadact(curract) -> absact
  adjustact(absact) -> curract
  

}

curract


